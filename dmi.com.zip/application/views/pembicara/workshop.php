<div class="tengah" id="main">

    <div class="judul-halaman">
        <div class="container">
            <h1>Pembicara Workshop</h1>
        </div>
    </div>

    <div class="hold-breadcrumbs">
        <div class="container">
            <ol class="breadcrumb breadcrumb-site">
                <li><a href="<?= base_url('home') ?>">Beranda</a></li>
                <li>Pembicara</li>
                <li class="active">Pembicara Workshop</li>
            </ol>
        </div>
    </div>

    <div class="container">
        <section class="advertising">
            <div class="container">
                <div class="row">
                    <div class="visi-sekolah">

                    </div>
                </div>
            </div>
        </section>
    </div>
</div>