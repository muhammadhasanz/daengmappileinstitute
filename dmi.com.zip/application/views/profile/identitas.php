<div class="tengah" id="main">
<div class="judul-halaman">
    <div class="container">
        <h1>Identitas Daeng Mappile Institute</h1>
    </div>
</div>

<div class="hold-breadcrumbs">
    <div class="container">
        <ol class="breadcrumb breadcrumb-site">
            <li><a href="<?= base_url('home') ?>">Beranda</a></li>
            <li>Profil</li>
            <li class="active">Identitas</li>
        </ol>
    </div>
</div>

<div class="container">
    <div class="row">
        
    </div>
</div>

</div>
